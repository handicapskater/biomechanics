package com.availity.spark.provider

import com.availity.spark.SparkTestSession
import com.availity.spark.provider.ProviderRoster._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.funspec.AnyFunSpec

class ProviderRosterSpec extends AnyFunSpec with SparkTestSession {

  override def beforeAll(): Unit = {
    super.beforeAll()
    spark = SparkSession.builder()
      .master("local[*]")
      .appName("ProviderRosterSpec Verification")
      .getOrCreate()
  }

  override def afterAll(): Unit = {
    if (spark != null) {
      spark.stop()
    }
    super.afterAll()
  }

  override def beforeEach(): Unit = {
    // This makes it easier to test
    cleanupLocalFileSystem()
  }

  override def afterEach(): Unit = {
  }

  val providersExpectedCount: Int = 1000
  val visitsExpectedCount: Int = 22347
  val providersExpectedMonthlyListCount: Int = 10074

  describe("ProviderRoster") {
    it("providers dataset count equals providers.csv count") {
      val providers = spark.read
        .option("header", "true")
        .csv("data/providers.csv")

      // Assume we are checking the count of records
      assert(providers.count() == providersExpectedCount)
    }

    it("visits dataset count equals visits.csv count") {
      val visits = spark.read
        .option("header", "true")
        .csv("data/visits.csv")

      // Perform another assertion or comparison
      assert(visits.count() == visitsExpectedCount)
    }

    it("processed provider visits is equal to the number of join visits") {
      val providers: DataFrame = setupProviders()
      val visits: DataFrame = setupVisits()
      val result: DataFrame = processProviderVisits(visits, providers)

      assert(providersExpectedCount == result.count())
    }

    it("processed provider visits per month is equal to the list of months visited") {
      val visits: DataFrame = setupVisits()
      val result: DataFrame = processProviderVisitsPerMonth(visits)

      assert(providersExpectedMonthlyListCount == result.count())
    }
  }
}
