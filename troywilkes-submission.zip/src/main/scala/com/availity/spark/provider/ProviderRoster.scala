package com.availity.spark.provider

import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.spark.sql.functions.{concat_ws, count, month, to_date}
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * Purpose: Join two csv files and generate json reports on total number of visits per provider partitioned by
 *  provider's specialty and total number of visits per provider per month. I refactored the code to demonstrate
 *  my Best Practices:
 *  1. Demonstrate code reusability in production classes and test classes.
 *  2. Ensure maintainability by making the code easier to manage.
 *  3. Increase reliability by testing functions independently.
 *  4. Performance is better managed by utilizing lazy evaluation plan, until Spark actions are necessary.
 *  5. Clean up temp files before execution to make it easier to run tests continually.
 *
 * Input:
 *  1. providers.csv - contained a header row with a specific delimiter.
 *  2. visits.csv - did not contain a header row.
 *
 * Output:
 *  1. total_visits_per_provider directory  - containing subdirectories named after the specialty with a json report.
 *  2. total_visits_per_provider_per_month directory - containing json report.
 *
 * Assumptions: My setup consisted of the following compliant versions:
 *  1. sbt version: 1.10.0
 *  2. scala version: 2.12.19
 *  3. spark version: 3.1.1
 *
 * Tests: Setup these tests to validate my submission.
 *  1. Compare "providers dataset count equals providers.csv count"
 *  2. Compare "visits dataset count equals visits.csv count"
 *  3. Compare "processed provider visits is equal to the number of join visits"
 *  4. Compare "processed provider visits per month is equal to the list of months visited"
 *
 * Submission: Packaging and submitting the project
 *  zip -r troywilkes-submission.zip README.md src project data build.sbt target/scala-2.12/providerroster*.jar
 *
 * Execution:
 *  1. Run program from sbt: sbt compile ; sbt run
 *  2. Run tests from sbt: sbt compile ; sbt test
 *  3. Run program with spark-submit, first package it with `sbt package`, then run it with command below.
 *  4. Run with java: java -jar target/scala-2.12/providerroster_2.12-1.0.0.jar
 */
/*
Spark Command:
spark-submit \
  --class com.availity.spark.provider.ProviderRoster \
  --master local[*] \
  target/scala-2.12/providerroster_2.12-1.0.0.jar
*/
object ProviderRoster {
  val spark = SparkSession.builder()
    .appName("Provider Visits Analysis")
    .master("local[*]")
    .getOrCreate()

  import spark.implicits._

  def main(args: Array[String]): Unit = {
    process()
  }

  // Check if the temp directory exists and delete
  def cleanupLocalFileSystem(): Unit = {
    val fs = FileSystem.get(spark.sparkContext.hadoopConfiguration)
    val tempPath1 = new Path("total_visits_per_provider")
    val tempPath2 = new Path("total_visits_per_provider_per_month")

    if (fs.exists(tempPath1)) {
      fs.delete(tempPath1, true)  // true for recursive delete
    }
    if (fs.exists(tempPath2)) {
      fs.delete(tempPath2, true)  // true for recursive delete
    }
  }

  // Load providers data concatenating name.
  def setupProviders(): DataFrame = {
    val providers: DataFrame = spark.read
      .option("header", "true")
      .option("delimiter", "|")
      .csv("data/providers.csv")

    // Optimization: Minimize transformations by concatenating the name early.
    val providersWithName = providers
      .withColumn("name", concat_ws(" ", $"first_name", $"middle_name", $"last_name"))
      .drop("first_name")
      .drop("middle_name")
      .drop("last_name")
      .select("provider_id", "name", "provider_specialty")

    providersWithName
  }

  // Load visits data.
  def setupVisits(): DataFrame = {
    // Define the visits schema
    val visitsSchema = new StructType()
      .add("visit_id", "String")
      .add("provider_id", "String")
      .add("visit_date", "Date")

    // Load visits data
    val visits = spark.read
      .option("header", "false")
      .schema(visitsSchema)
      .csv("data/visits.csv")

    visits
  }

  // Setup environment and run processes.
  def process(): Unit = {
    val providers: DataFrame = setupProviders()
    val visits: DataFrame = setupVisits()

    cleanupLocalFileSystem()
    processProviderVisits(visits, providers)
    processProviderVisitsPerMonth(visits)
  }

  // Process total visits per provider and partitioned.
  def processProviderVisits(visits: DataFrame, providers: DataFrame): DataFrame = {
    // Calculate total visits per provider
    val totalVisitsPerProvider = visits
      .groupBy("provider_id")
      .agg(count("*").alias("total_visits"))
      .join(providers, visits("provider_id") === providers("provider_id"), "inner")
      .drop(providers("provider_id"))
      .select("provider_id", "name", "provider_specialty", "total_visits")

    // Write results partitioned by specialty in JSON format
    totalVisitsPerProvider
      .coalesce(1)
      .write
      .partitionBy("provider_specialty")
      .json("total_visits_per_provider")

    totalVisitsPerProvider
  }

  // Process visits per month.
  def processProviderVisitsPerMonth(visits: DataFrame): DataFrame = {
    // Calculate total visits per provider per month
    val totalVisitsPerProviderPerMonth = visits
      .withColumn("month", month(to_date(visits("visit_date"), "yyyy-MM-dd")))
      .groupBy("provider_id", "month")
      .agg(count("*").alias("monthly_visits"))
      .orderBy("provider_id", "month")

    // Write results in JSON format
    totalVisitsPerProviderPerMonth
      .coalesce(1)
      .write
      .json("total_visits_per_provider_per_month")

    totalVisitsPerProviderPerMonth
  }
}
